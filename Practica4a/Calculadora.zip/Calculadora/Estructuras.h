struct Operacion{
	int num1;
	int num2;

};
